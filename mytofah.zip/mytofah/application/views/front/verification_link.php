<a href="<?php echo base_url()?>" target="_blank">Click here to visit the site and login</a>
      
    