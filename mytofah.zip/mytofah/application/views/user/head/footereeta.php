<footer class="row">
  <div class="container">
    <div class="col-lg-4"> <img src="<?php echo base_url();?>ui/user/img/footer-logo.png" /> <br />
      <br />
      <p>Lorem ipsum dolor sit amet, consectetuer adipiscing elit. Aenean commodo ligula eget dolor. Aenean massa. Cum sociis natoque penatibus et magnis dis parturient montes, nascetur ridiculus mus. Donec quam felis, Read More.. </p>
    </div>
    <div class="col-lg-3 col-lg-offset-1 foot-nav">
      <h2>COMPANY INFO</h2>
      <li><a href="#">About Us</a></li>
      <li><a href="#">Pressroom / News & updates</a></li>
      <li><a href="#">Blogs</a></li>
      <li><a href="#">Contact Us</a></li>
      <li><a href="#">Faq</a></li>
    </div>
    <div class="col-lg-3 col-lg-offset-1 foot-nav">
      <h2>Get In Touch</h2>
      <img src="<?php echo base_url();?>ui/user/img/twitter.png" /> <img src="<?php echo base_url();?>ui/user/img/google.png" /> <img src="<?php echo base_url();?>ui/user/img/skype.png" /> <img src="<?php echo base_url();?>ui/user/img/facebook.png" /> <img src="<?php echo base_url();?>ui/user/img/linked.png" /> <br />
      <br />
      <h2>Newsletter Subscribe</h2>
      <input class="nws-ltr" type="text" placeholder="email address" />
      <button class="btn-go">Go</button>
    </div>
  </div>
</footer>
<div class="row" style="background-color:#000; padding:10px; text-align:center; color:#FFF; font-size:12px"> All Rights Reserved, Copyright @2016 </div>
<script src='<?php echo base_url();?>ui/user/js/rSlider.min.js'></script>

<script src="<?php echo base_url();?>ui/model/classie.js"></script> 
<script src="<?php echo base_url();?>ui/model/modalEffects.js"></script> 

<!-- for the blur effect --> 
<!-- by @derSchepp https://github.com/Schepp/CSS-Filters-Polyfill --> 
<script>
			// this is important for IEs
			var polyfilter_scriptpath = '/js/';
		</script> 
<script src="<?php echo base_url();?>ui/model/cssParser.js"></script> 
<script src="<?php echo base_url();?>ui/model/css-filters-polyfill.js"></script>
</body>
</html>